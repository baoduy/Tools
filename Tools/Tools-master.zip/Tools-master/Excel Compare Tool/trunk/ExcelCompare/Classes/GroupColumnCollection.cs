using System;
using System.Collections.Generic;
using System.Text;

namespace ExcelCompare.Classes
{
    public class GroupColumnCollection : List<string>
    {
    }
}

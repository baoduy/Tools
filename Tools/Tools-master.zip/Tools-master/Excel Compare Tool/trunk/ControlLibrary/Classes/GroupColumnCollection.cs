using System;
using System.Collections.Generic;
using System.Text;

namespace ControlLibrary.Classes
{
    public class GroupColumnCollection : List<string>
    {
    }
}

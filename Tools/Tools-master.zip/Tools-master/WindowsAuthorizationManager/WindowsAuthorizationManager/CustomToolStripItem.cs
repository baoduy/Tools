﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindowsAuthorizationManager
{
    public class CustomToolStripItem : ToolStripMenuItem
    {
        public object Value { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using ExcelCompare.Classes;

namespace ExcelCompare.UserControls
{
    public partial class OpenExcelFile : UserControl
    {
        public string FullFileName
        {
            get { return this.fileBrowserDialog.FullFileName; }
            set { this.fileBrowserDialog.FullFileName = value; }
        }

        public string FileName
        {
            get { return this.fileBrowserDialog.FileName; }
        }

        public string SheetName
        {
            get { return this.dataSheetName.Text; }
            set { this.dataSheetName.SelectedValue = value; }
        }

        public OpenExcelFile()
        {
            InitializeComponent();

            this.fileBrowserDialog.FilePathChanged += new EventHandler(fileBrowserDialog_FilePathChanged);
            this.fileBrowserDialog.Filter = Properties.Settings.Default.ExcelExtension;
            this.fileBrowserDialog.Multiselect = false;
        }

        DataTable data;
        public DataTable DataTable
        {
            get
            {
                if (this.data == null)
                    this.GetData();
                else if (this.data.TableName != this.dataSheetName.Text)
                    this.GetData();

                return this.data;
            }
        }

        public IList<DataColumn> Columns
        {
            get
            {
                IList<DataColumn> list = new List<DataColumn>();
                if (this.DataTable != null)
                {
                    foreach (DataColumn col in this.DataTable.Columns)
                        list.Add(col);
                }

                return list;
            }
        }

        private void GetData()
        {
            if (string.IsNullOrEmpty(this.fileBrowserDialog.FullFileName))
            { return; }

            if (this.fileBrowserDialog.FullFileName.Contains("csv"))
                this.data = ExcelConverter.CSVtoDataTable(this.fileBrowserDialog.FullFileName);
            else this.data = ExcelConverter.XSLtoDataTable(this.fileBrowserDialog.FullFileName, this.dataSheetName.Text);

            if (this.data != null)
                this.data.TableName = this.dataSheetName.Text;
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);

            this.Height = this.dataSheetName.Height + 10;
        }

        private void fileBrowserDialog_FilePathChanged(object sender, EventArgs e)
        {
            this.dataSheetName.Items.Clear();

            if (!string.IsNullOrEmpty(this.fileBrowserDialog.FullFileName))
            {
                string[] sheetNames = ExcelConverter.GetExcelSheetNames(this.fileBrowserDialog.FullFileName);
                if (sheetNames != null)
                {
                    foreach (string s in sheetNames)
                        this.dataSheetName.Items.Add(s);

                    this.dataSheetName.SelectedIndex = 0;
                }
            }
        }

        private void dataSheetName_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.OnSheetNameSelectionChanged(e);
        }

        public event System.EventHandler SheetNameSelectionChanged;
        protected virtual void OnSheetNameSelectionChanged(EventArgs e)
        {
            this.data = null;
            if (this.SheetNameSelectionChanged != null)
                this.SheetNameSelectionChanged(this, e);
        }
    }
}

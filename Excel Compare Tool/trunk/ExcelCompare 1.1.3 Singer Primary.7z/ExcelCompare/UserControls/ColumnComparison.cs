﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;

using System.Text;
using System.Windows.Forms;

namespace ExcelCompare.UserControls
{
    public partial class ColumnComparison : UserControl
    {
        [DefaultValue(null)]
        public IList<DataColumn> ColumnsA
        {
            get { return this.comboBoxA.DataSource as IList<DataColumn>; }
            set
            {
                this.comboBoxA.DataSource = value;
            }
        }

        [DefaultValue(null)]
        public IList<DataColumn> ColumnsB
        {
            get { return this.comboBoxB.DataSource as IList<DataColumn>; }
            set
            {
                this.comboBoxB.DataSource = value;
            }
        }

        [DefaultValue(null)]
        public DataColumn SelectedColumnA
        {
            get { return this.comboBoxA.SelectedItem as DataColumn; }
            set { this.comboBoxA.SelectedItem = value; }
        }

        [DefaultValue(null)]
        public DataColumn SelectedColumnB
        {
            get { return this.comboBoxB.SelectedItem as DataColumn; }
            set { this.comboBoxB.SelectedItem = value; }
        }

        public bool ShowEnable
        {
            get { return this.chEnable.Visible; }
            set { this.chEnable.Visible = value; }
        }

        public ColumnComparison()
        {
            InitializeComponent();
        }

        private void chEnable_CheckedChanged(object sender, EventArgs e)
        {
            this.comboBoxA.Enabled = this.comboBoxB.Enabled = this.chEnable.Checked;
        }

        protected override void OnSizeChanged(EventArgs e)
        {
            base.OnSizeChanged(e);

            this.Height = this.comboBoxA.Height + 5;
        }
    }
}

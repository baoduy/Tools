﻿namespace ExcelCompare
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.listColumnComparision = new ExcelCompare.UserControls.ListColumnComparision();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btCompare = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.excelFileB = new ExcelCompare.UserControls.OpenExcelFile();
            this.label1 = new System.Windows.Forms.Label();
            this.excelFileA = new ExcelCompare.UserControls.OpenExcelFile();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.oriDataGrids = new ExcelCompare.UserControls.CompareDataGrids();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.resultDataGrids = new ExcelCompare.UserControls.CompareDataGrids();
            this.groupResultTab = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.lbFileB = new System.Windows.Forms.LinkLabel();
            this.btExportToXLS = new System.Windows.Forms.Button();
            this.lbFileA = new System.Windows.Forms.LinkLabel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.chShowOnlyDiffCol = new System.Windows.Forms.CheckBox();
            this.chOnlyCompareCol = new System.Windows.Forms.CheckBox();
            this.toolStrip = new System.Windows.Forms.ToolStrip();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.chShowDiffRow = new System.Windows.Forms.CheckBox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupResultTab.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.toolStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 25);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(792, 755);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.listColumnComparision);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(784, 729);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Input Data";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // listColumnComparision
            // 
            this.listColumnComparision.ColumnsA = null;
            this.listColumnComparision.ColumnsB = null;
            this.listColumnComparision.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listColumnComparision.Location = new System.Drawing.Point(3, 99);
            this.listColumnComparision.Name = "listColumnComparision";
            this.listColumnComparision.SheetAName = "Sheet A";
            this.listColumnComparision.SheetBName = "Sheet B";
            this.listColumnComparision.Size = new System.Drawing.Size(778, 579);
            this.listColumnComparision.TabIndex = 5;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btCompare);
            this.groupBox2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupBox2.Location = new System.Drawing.Point(3, 678);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(778, 48);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            // 
            // btCompare
            // 
            this.btCompare.Dock = System.Windows.Forms.DockStyle.Right;
            this.btCompare.Location = new System.Drawing.Point(625, 16);
            this.btCompare.Name = "btCompare";
            this.btCompare.Size = new System.Drawing.Size(150, 29);
            this.btCompare.TabIndex = 4;
            this.btCompare.Text = "Compare";
            this.btCompare.UseVisualStyleBackColor = true;
            this.btCompare.Click += new System.EventHandler(this.btCompare_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.excelFileB);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.excelFileA);
            this.groupBox1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupBox1.Location = new System.Drawing.Point(3, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(778, 96);
            this.groupBox1.TabIndex = 3;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Files Comparison";
            // 
            // excelFileB
            // 
            this.excelFileB.Dock = System.Windows.Forms.DockStyle.Top;
            this.excelFileB.FullFileName = "";
            this.excelFileB.Location = new System.Drawing.Point(3, 60);
            this.excelFileB.Name = "excelFileB";
            this.excelFileB.SheetName = "";
            this.excelFileB.Size = new System.Drawing.Size(772, 31);
            this.excelFileB.TabIndex = 2;
            this.excelFileB.SheetNameSelectionChanged += new System.EventHandler(this.excelFileB_SheetNameSelectionChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Location = new System.Drawing.Point(3, 47);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(77, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Compare With:";
            // 
            // excelFileA
            // 
            this.excelFileA.Dock = System.Windows.Forms.DockStyle.Top;
            this.excelFileA.FullFileName = "";
            this.excelFileA.Location = new System.Drawing.Point(3, 16);
            this.excelFileA.Name = "excelFileA";
            this.excelFileA.SheetName = "";
            this.excelFileA.Size = new System.Drawing.Size(772, 31);
            this.excelFileA.TabIndex = 0;
            this.excelFileA.SheetNameSelectionChanged += new System.EventHandler(this.excelFileA_SheetNameSelectionChanged);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.oriDataGrids);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(784, 729);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Original Data";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // oriDataGrids
            // 
            this.oriDataGrids.Dock = System.Windows.Forms.DockStyle.Fill;
            this.oriDataGrids.Location = new System.Drawing.Point(3, 3);
            this.oriDataGrids.Name = "oriDataGrids";
            this.oriDataGrids.Size = new System.Drawing.Size(778, 723);
            this.oriDataGrids.TabIndex = 0;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.resultDataGrids);
            this.tabPage3.Controls.Add(this.groupResultTab);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(784, 729);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Compare Result";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // resultDataGrids
            // 
            this.resultDataGrids.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resultDataGrids.Location = new System.Drawing.Point(0, 80);
            this.resultDataGrids.Name = "resultDataGrids";
            this.resultDataGrids.Size = new System.Drawing.Size(784, 649);
            this.resultDataGrids.TabIndex = 0;
            this.resultDataGrids.SelectionChanged += new System.EventHandler(this.resultDataGrids_SelectionChanged);
            // 
            // groupResultTab
            // 
            this.groupResultTab.Controls.Add(this.tableLayoutPanel1);
            this.groupResultTab.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupResultTab.Location = new System.Drawing.Point(0, 0);
            this.groupResultTab.Name = "groupResultTab";
            this.groupResultTab.Size = new System.Drawing.Size(784, 80);
            this.groupResultTab.TabIndex = 1;
            this.groupResultTab.TabStop = false;
            this.groupResultTab.Text = "Export";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.lbFileB, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.btExportToXLS, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.lbFileA, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(3, 16);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(778, 61);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // lbFileB
            // 
            this.lbFileB.AutoSize = true;
            this.lbFileB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbFileB.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbFileB.Location = new System.Drawing.Point(392, 30);
            this.lbFileB.Name = "lbFileB";
            this.lbFileB.Size = new System.Drawing.Size(383, 31);
            this.lbFileB.TabIndex = 3;
            this.lbFileB.TabStop = true;
            this.lbFileB.Text = "Excel File A : Sheet A";
            this.lbFileB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbFileB.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lbFileA_LinkClicked);
            // 
            // btExportToXLS
            // 
            this.btExportToXLS.Dock = System.Windows.Forms.DockStyle.Right;
            this.btExportToXLS.Location = new System.Drawing.Point(678, 3);
            this.btExportToXLS.Name = "btExportToXLS";
            this.btExportToXLS.Size = new System.Drawing.Size(97, 24);
            this.btExportToXLS.TabIndex = 0;
            this.btExportToXLS.Text = "Export to Excel";
            this.btExportToXLS.UseVisualStyleBackColor = true;
            this.btExportToXLS.Click += new System.EventHandler(this.btExportToXLS_Click);
            // 
            // lbFileA
            // 
            this.lbFileA.AutoSize = true;
            this.lbFileA.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lbFileA.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbFileA.Location = new System.Drawing.Point(3, 30);
            this.lbFileA.Name = "lbFileA";
            this.lbFileA.Size = new System.Drawing.Size(383, 31);
            this.lbFileA.TabIndex = 2;
            this.lbFileA.TabStop = true;
            this.lbFileA.Text = "Excel File A : Sheet A";
            this.lbFileA.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbFileA.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lbFileA_LinkClicked);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.chShowDiffRow);
            this.panel1.Controls.Add(this.chShowOnlyDiffCol);
            this.panel1.Controls.Add(this.chOnlyCompareCol);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(383, 24);
            this.panel1.TabIndex = 4;
            // 
            // chShowOnlyDiffCol
            // 
            this.chShowOnlyDiffCol.AutoSize = true;
            this.chShowOnlyDiffCol.Dock = System.Windows.Forms.DockStyle.Left;
            this.chShowOnlyDiffCol.Location = new System.Drawing.Point(164, 0);
            this.chShowOnlyDiffCol.Name = "chShowOnlyDiffCol";
            this.chShowOnlyDiffCol.Size = new System.Drawing.Size(162, 24);
            this.chShowOnlyDiffCol.TabIndex = 3;
            this.chShowOnlyDiffCol.Text = "Show only difference column";
            this.chShowOnlyDiffCol.UseVisualStyleBackColor = true;
            this.chShowOnlyDiffCol.CheckedChanged += new System.EventHandler(this.chShowOnlyDiffCol_CheckedChanged);
            // 
            // chOnlyCompareCol
            // 
            this.chOnlyCompareCol.AutoSize = true;
            this.chOnlyCompareCol.Dock = System.Windows.Forms.DockStyle.Left;
            this.chOnlyCompareCol.Location = new System.Drawing.Point(0, 0);
            this.chOnlyCompareCol.Name = "chOnlyCompareCol";
            this.chOnlyCompareCol.Size = new System.Drawing.Size(164, 24);
            this.chOnlyCompareCol.TabIndex = 2;
            this.chOnlyCompareCol.Text = "Show only comparing column";
            this.chOnlyCompareCol.UseVisualStyleBackColor = true;
            this.chOnlyCompareCol.CheckedChanged += new System.EventHandler(this.chOnlyCompareColumns_CheckedChanged);
            // 
            // toolStrip
            // 
            this.toolStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton1});
            this.toolStrip.Location = new System.Drawing.Point(0, 0);
            this.toolStrip.Name = "toolStrip";
            this.toolStrip.Size = new System.Drawing.Size(792, 25);
            this.toolStrip.TabIndex = 1;
            this.toolStrip.Text = "toolStrip1";
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text;
            this.toolStripButton1.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton1.Image")));
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(63, 22);
            this.toolStripButton1.Text = "CSV to XLS";
            this.toolStripButton1.ToolTipText = "Convert CSV to Excel";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // chShowDiffRow
            // 
            this.chShowDiffRow.AutoSize = true;
            this.chShowDiffRow.Dock = System.Windows.Forms.DockStyle.Left;
            this.chShowDiffRow.Location = new System.Drawing.Point(326, 0);
            this.chShowDiffRow.Name = "chShowDiffRow";
            this.chShowDiffRow.Size = new System.Drawing.Size(145, 24);
            this.chShowDiffRow.TabIndex = 4;
            this.chShowDiffRow.Text = "Show only difference row";
            this.chShowDiffRow.UseVisualStyleBackColor = true;
            this.chShowDiffRow.CheckedChanged += new System.EventHandler(this.chShowDiffRow_CheckedChanged);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(792, 780);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.toolStrip);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "MainForm";
            this.Text = "Excel Comparer";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.groupResultTab.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.toolStrip.ResumeLayout(false);
            this.toolStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private UserControls.ListColumnComparision listColumnComparision;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button btCompare;
        private System.Windows.Forms.GroupBox groupBox1;
        private UserControls.OpenExcelFile excelFileB;
        private System.Windows.Forms.Label label1;
        private UserControls.OpenExcelFile excelFileA;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage2;
        private UserControls.CompareDataGrids oriDataGrids;
        private UserControls.CompareDataGrids resultDataGrids;
        private System.Windows.Forms.GroupBox groupResultTab;
        private System.Windows.Forms.Button btExportToXLS;
        private System.Windows.Forms.ToolStrip toolStrip;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.LinkLabel lbFileB;
        private System.Windows.Forms.LinkLabel lbFileA;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.CheckBox chShowOnlyDiffCol;
        private System.Windows.Forms.CheckBox chOnlyCompareCol;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.CheckBox chShowDiffRow;
    }
}
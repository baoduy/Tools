﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Collections.ObjectModel;

namespace ExcelCompare.Classes
{
    public class DataComparer
    {
        public static ReadOnlyCollection<CompareColumnName> Diffrence(DataRow rowA, DataRow rowB, IList<CompareColumnName> Columns)
        {
            IList<CompareColumnName> list = new List<CompareColumnName>();

            foreach (CompareColumnName col in Columns)
            {
                object valA = rowA[col.ColumnA];
                object valB = rowB[col.ColumnB];
                bool diff = false;

                if (valA != null && valB != null)
                {
                    if (valA.ToString().Trim().ToLower() != valB.ToString().Trim().ToLower())
                    {
                        diff = true;
                    }
                }
                else if (valA != null || valB != null)
                {
                    diff = true;
                }

                if (diff)
                {
                    list.Add(col);
                }
            }

            return new ReadOnlyCollection<CompareColumnName>(list);
        }

        private static KeyValuePair<DataRow, ReadOnlyCollection<CompareColumnName>> FindLessDifference(DataRow rowA, DataRow[] rowArray, CompareColumnNameCollection columnCompares)
        {
            ReadOnlyCollection<CompareColumnName> currentCells = null;
            DataRow currentRow = null;

            foreach (DataRow rowB in rowArray)
            {
                ReadOnlyCollection<CompareColumnName> cells = DataComparer.Diffrence(rowA, rowB, columnCompares);
                if (cells != null)
                {
                    if (currentCells == null || cells.Count < currentCells.Count)
                    {
                        currentCells = cells;
                        currentRow = rowB;
                    }
                }
            }

            return new KeyValuePair<DataRow, ReadOnlyCollection<CompareColumnName>>(currentRow, currentCells);
        }

        public static CompareTablesResult Compare(CompareTable compareInfo)
        {
            CompareTablesResult result = new CompareTablesResult();
            result.TableA = new DataTable(compareInfo.TableA.TableName);
            result.TableB = new DataTable(compareInfo.TableB.TableName);
            result.DifferenceCells = new List<DifferenceCell>();

            #region Copy Column
            foreach (DataColumn colA in compareInfo.TableA.Columns)
            {
                result.TableA.Columns.Add(colA.ColumnName, colA.DataType);
            }

            foreach (DataColumn colB in compareInfo.TableB.Columns)
            {
                result.TableB.Columns.Add(colB.ColumnName, colB.DataType);
            }
            #endregion

            IList<DataRow> notFoundTableA = new List<DataRow>();
            IList<DataRow> notFoundTableB = new List<DataRow>();

            if (compareInfo.PrimaryColumn != null)
            {
                #region Compare with Primary key
                IList<string> comparedKeys = new List<string>();
                foreach (DataRow rowA in compareInfo.TableA.Rows)
                {
                    object priAval = rowA[compareInfo.PrimaryColumn.ColumnA];

                    if (priAval == null)
                        continue;
                    //if (comparedKeys.Contains(priAval.ToString().Trim().ToLower()))
                    //    continue;

                    #region Find each rowA in TableB
                    comparedKeys.Add(priAval.ToString().Trim().ToLower());

                    DataRow[] rowsB = null;
                    try
                    {
                        rowsB = compareInfo.TableB.Select(string.Format("[{0}] = '{1}'", compareInfo.PrimaryColumn.ColumnB, priAval));
                    }
                    catch (EvaluateException)
                    { rowsB = compareInfo.TableB.Select(string.Format("[{0}] = {1}", compareInfo.PrimaryColumn.ColumnB, priAval)); }

                    //Found Row
                    if (rowsB != null && rowsB.Length > 0)
                    {
                        //all row is the same data. So get 1 row to compare.
                        //DataRow rowB = rowsB[0];

                        //ReadOnlyCollection<CompareColumnName> cells = DataComparer.Diffrence(rowA, rowB, compareInfo.CompareColumns);
                        KeyValuePair<DataRow, ReadOnlyCollection<CompareColumnName>> dataRowCell = DataComparer.FindLessDifference(rowA, rowsB, compareInfo.CompareColumns);

                        if (dataRowCell.Key != null)
                        {
                            result.TableA.Rows.Add(rowA.ItemArray);
                            result.TableB.Rows.Add(dataRowCell.Key.ItemArray);

                            foreach (CompareColumnName cell in dataRowCell.Value)
                            {
                                DifferenceCell diff = new DifferenceCell();
                                diff.RowIndex = result.TableA.Rows.Count - 1;
                                diff.ColumnA = cell.ColumnA;
                                diff.ColumnB = cell.ColumnB;
                                result.DifferenceCells.Add(diff);
                            }
                        }
                    }
                    //Not Found Row
                    else notFoundTableA.Add(rowA);
                    #endregion
                }

                #region Find each rowB in TableA to collect NotFoundRowB.
                foreach (DataRow rowB in compareInfo.TableB.Rows)
                {
                    object priBval = rowB[compareInfo.PrimaryColumn.ColumnB];

                    if (priBval == null)
                        continue;
                    if (comparedKeys.Contains(priBval.ToString().Trim().ToLower()))
                        continue;

                    notFoundTableB.Add(rowB);
                }
                #endregion
                #endregion
            }
            else
            {
                #region Comare Row by Row
                int rowsCount = compareInfo.TableA.Rows.Count > compareInfo.TableB.Rows.Count ?
                    compareInfo.TableB.Rows.Count : compareInfo.TableA.Rows.Count;

                for (int i = 0; i < rowsCount; i++)
                {
                    DataRow rowA = compareInfo.TableA.Rows[i];
                    DataRow rowB = compareInfo.TableB.Rows[i];

                    ReadOnlyCollection<CompareColumnName> cells = Diffrence(rowA, rowB, compareInfo.CompareColumns);
                    if (cells != null)
                    {
                        result.TableA.Rows.Add(rowA.ItemArray);
                        result.TableB.Rows.Add(rowB.ItemArray);

                        foreach (CompareColumnName cell in cells)
                        {
                            DifferenceCell diff = new DifferenceCell();
                            diff.RowIndex = result.TableA.Rows.Count - 1;
                            diff.ColumnA = cell.ColumnA;
                            diff.ColumnB = cell.ColumnB;

                            result.DifferenceCells.Add(diff);
                        }
                    }
                }
                #endregion
            }

            #region Add NotFoundRows
            result.NotFoundTableARowIndex = new List<int>();
            result.NotFoundTableBRowIndex = new List<int>();

            foreach (DataRow row in notFoundTableA)
            {
                result.NotFoundTableARowIndex.Add(result.TableA.Rows.Count);
                result.TableA.Rows.Add(row.ItemArray);
                result.TableB.Rows.Add();

            }

            foreach (DataRow row in notFoundTableB)
            {
                result.NotFoundTableBRowIndex.Add(result.TableB.Rows.Count);
                result.TableB.Rows.Add(row.ItemArray);
                result.TableA.Rows.Add();
            }
            #endregion

            return result;
        }
    }
}
